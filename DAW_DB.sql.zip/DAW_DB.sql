-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 03, 2017 at 05:43 AM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `DAW`
--

-- --------------------------------------------------------

--
-- Table structure for table `Candidate`
--

DROP DATABASE IF EXISTS DAW;

CREATE DATABASE DAW;

USE DAW;

CREATE TABLE `Candidate` (
  `id` int(11) DEFAULT NULL,
  `firstName` text,
  `lastName` text,
  `address` text,
  `phone` text,
  `email` text,
  `title` text,
  `university` text,
  `certificates` text,
  `expectatives` int(11) DEFAULT NULL,
  `interview` int(11) DEFAULT NULL,
  `previous` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Candidate`
--

INSERT INTO `Candidate` (`id`, `firstName`, `lastName`, `address`, `phone`, `email`, `title`, `university`, `certificates`, `expectatives`, `interview`, `previous`) VALUES
(1, 'asdfasdf', 'asdf', 'asdf', 'ads', 'ads', 'ads', 'sad', '1', 1, 3, 'asdf'),
(1, 'asd', 'adfs', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf', '1', 1, 3, 'adds');

-- --------------------------------------------------------

--
-- Table structure for table `producto`
--

CREATE TABLE `producto` (
  `idProducto` int(11) NOT NULL,
  `nombreProducto` varchar(50) NOT NULL,
  `idCategoria` int(11) NOT NULL,
  `cantidadUnidades` int(11) NOT NULL,
  `precio` decimal(13,2) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `producto`
--

INSERT INTO `producto` (`idProducto`, `nombreProducto`, `idCategoria`, `cantidadUnidades`, `precio`, `foto`) VALUES
(1, 'Backstreet Boys CD', 1, 100, '19.99', 'bsb_cd.jpg'),
(3, 'asdf', 1, 1, '1.00', 'asdfdf');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `id` int(11) DEFAULT NULL,
  `email` text,
  `password` text,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `numLogin` int(11) DEFAULT NULL,
  `estatusCuenta` enum('activa','bloqueada') NOT NULL DEFAULT 'activa',
  `tipoUsuario` enum('administrador','vendedor','gerente','ventas') DEFAULT NULL,
  `primerLogin` enum('y','n') NOT NULL DEFAULT 'y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User`
--


INSERT INTO `User` (`id`, `email`, `password`, `nombre`, `apellido`, `username`, `numLogin`, `estatusCuenta`, `tipoUsuario`, `primerLogin`) VALUES
  ('1', 'correo@correo.com', 'password', 'Eugenio', 'Rangel', 'erangel92', 0, 'activa', 'administrador', 'n'),
  ('2', 'carlos@correo.com', '123456', 'Carlos', 'Aguilar', 'carlosAguilar', 0, 'activa', 'vendedor', 'n'),
  ('3', 'genaro@correo.com', 'gen123', 'Genaro', 'Martinez', 'genarMart', 0, 'activa', 'ventas', 'n'),
  ('4', 'nacho@correo.com', 'nachito', 'Ignacio', 'Guarda', 'nachoGuarda', 0, 'activa', 'gerente', 'n'),
(5, 'admin@admin', 'admin', 'Admin', 'Admin', 'admin', 0, 'activa', 'administrador', 'n'),
(6, 'asdfasdf', 'asdfasdf', 'aasdfasdf', 'adsfasdf', 'add', 0, 'activa', 'gerente', 'n'),
(8, 'staff', 'asdf', 'add', 'sad', 'ads', 0, 'activa', 'vendedor', 'n'),
(9, 'asdf', 'sadf', 'asdf', 'asdf', 'asdf', 0, 'activa', 'vendedor', 'n'),
(10, 'asdf', 'dsf', 'pdf', 'adsf', 'asdf', 0, 'activa', 'gerente', 'y'),
(12, 'ads', 'asdf', 'asdf', 'asdf', 'asdfasdfasdf', 0, 'activa', 'administrador', 'y'),
(13, 'asdf', 'adsf', 'asdf', 'asdf', 'putin', 0, 'activa', 'vendedor', 'n');